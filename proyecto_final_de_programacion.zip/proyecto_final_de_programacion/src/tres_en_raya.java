public class tres_en_raya {
    public static void main(String[] args) {
        JuegoTresEnRaya juego = new JuegoTresEnRaya();
        juego.iniciarJuego();
    }
}
